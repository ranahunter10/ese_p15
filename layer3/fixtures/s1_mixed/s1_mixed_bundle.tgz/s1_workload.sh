#!/bin/bash
# S1 workload: every edge type the graph builds, each step timestamped.
M=~/p2_data/s1_markers.txt; : > "$M"
mark(){ echo "$(date +%s%N) $1" >> "$M"; }
W=/tmp/s1w; rm -rf "$W"; mkdir -p "$W"; cd "$W"

mark EXEC_simple;      ls -la /etc >/dev/null; uname -a >/dev/null; ps aux >/dev/null
mark EXEC_chain;       bash -c 'sh -c "cat /etc/hostname >/dev/null"'
mark EXEC_failed;      /nonexistent_binary_s1 2>/dev/null; true
mark FILE_write;       echo "hello s1" > "$W/a.txt"
mark FILE_read;        cat "$W/a.txt" >/dev/null
mark FILE_copy;        cp "$W/a.txt" "$W/b.txt"
mark FILE_append;      echo "more" >> "$W/b.txt"
mark FILE_rdwr;        python3 -c "f=open('$W/b.txt','r+'); f.read(); f.write('x'); f.close()"
mark FILE_flow;        echo "secret" > "$W/drop.txt"; bash -c "cat $W/drop.txt > $W/exfil.txt"
mark NET_local_server; python3 -m http.server 8765 --bind 127.0.0.1 >/dev/null 2>&1 & SRV=$!; sleep 1
mark NET_local_fetch;  python3 -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8765/',timeout=5).read()"
mark NET_local_fetch2; python3 -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8765/',timeout=5).read()"
kill $SRV; wait $SRV 2>/dev/null
mark NET_outbound;     python3 -c "import urllib.request;urllib.request.urlopen('http://example.com',timeout=5).read()" 2>/dev/null || mark NET_outbound_FAILED
mark DONE
